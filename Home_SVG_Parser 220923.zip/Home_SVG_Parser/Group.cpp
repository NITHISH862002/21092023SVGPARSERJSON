#include <iostream>
#include "path.cpp"
// #ifndef __PATH__H_
// #define __PATH_H_

class Group : public Shape
{
public:
    Group() : Shape("Group") { std::cout << "group"; }
};
// #endif