#include <iostream>
// #include "Path.cpp"
// #include "D:\C++\SVG_Parser\Home_SVG_Parser\Elements\Path.cpp"
#include "../Elements/Path.cpp"
#ifndef __OTHERS__H_
#define __OTHERS__H_
class Others : public Shape
{
public:
   string d{};
   string Element{};
   Others() : Shape("Path") {}
   Others(string attributes) : Shape("Others")
   {
      Element = attributes ;
      cout << Element << endl;
   }
};
#endif