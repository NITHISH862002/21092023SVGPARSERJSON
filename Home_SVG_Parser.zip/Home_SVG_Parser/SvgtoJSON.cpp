#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "pugixml.cpp"
#include "json.hpp"
// #include "DynamicFileObject.cpp"
using namespace std;
using json = nlohmann::json;
class SvgtoJson
{
public:
    std::string svgtojson(std::string &s);
    json nodeToJson(const pugi::xml_node &node);
};

std::string SvgtoJson::svgtojson(std::string &s)
{
    try
    {
        // Load the SVG file using PugiXML
      char *x = (char *)s.c_str();
        std::ifstream svgFile(x);
        std::string svgContent((std::istreambuf_iterator<char>(svgFile)), std::istreambuf_iterator<char>());

        // Parse the SVG content using PugiXML
        pugi::xml_document doc;
        pugi::xml_parse_result result = doc.load_string(svgContent.c_str());

        // Check for parsing errors
        if (result.status != pugi::xml_parse_status::status_ok)
        {
            std::cerr << "Failed to parse SVG file. Error description: " << result.description() << std::endl;
            std::cout << "false";
        }

        // Convert the SVG DOM to JSON
        json svgJson = nodeToJson(doc.child("svg"));

        // Serialize JSON to a string and print or save it
        // cout << svgJson.dump(4) << endl;

        // Optionally, you can save the JSON to a file
        ofstream outputFile("output.json");
        outputFile << svgJson.dump(4);
        outputFile.close();
        cout<<"Your JSON file has been saved as output.json.\n";
    }
    catch (const exception &e)
    {
        cerr << "An exception occurred: " << e.what() << endl;
        return "1";
    }
    return "0";
}

json SvgtoJson::nodeToJson(const pugi::xml_node &node)
{
    json jsonNode;

    // Process attributes
    for (const pugi::xml_attribute &attr : node.attributes())
    {
        jsonNode[attr.name()] = attr.value();
    }

    // Process child nodes
    for (const pugi::xml_node &child : node.children())
    {
        jsonNode[child.name()].push_back(nodeToJson(child));
    }

    return jsonNode;
}
